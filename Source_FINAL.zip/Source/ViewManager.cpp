///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

namespace
{
	// Window and camera settings
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	Camera* g_pCamera = nullptr;
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;
	bool bOrthographicProjection = false;
}

ViewManager::ViewManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 45.0f; // Standard FOV
	g_pCamera->MovementSpeed = 3.0f;
	g_pCamera->MouseSensitivity = 0.1f;
}

ViewManager::~ViewManager()
{
	if (g_pCamera) delete g_pCamera;
}

GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, NULL, NULL);
	if (!window) {
		std::cerr << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}

	glfwMakeContextCurrent(window);
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
	glfwSetScrollCallback(window, [](GLFWwindow* w, double x, double y) {
		if (g_pCamera) g_pCamera->ProcessMouseScroll(y);
		});

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	m_pWindow = window;
	return window;
}

void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xpos, double ypos)
{
	if (gFirstMouse) {
		gLastX = xpos;
		gLastY = ypos;
		gFirstMouse = false;
	}

	float xoffset = xpos - gLastX;
	float yoffset = gLastY - ypos; // Reversed Y
	gLastX = xpos;
	gLastY = ypos;

	if (g_pCamera) {
		g_pCamera->ProcessMouseMovement(xoffset, yoffset);
	}
}

void ViewManager::ProcessKeyboardEvents()
{
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(m_pWindow, true);

	if (!g_pCamera) return;

	float velocity = g_pCamera->MovementSpeed * gDeltaTime;

	// Movement controls (WASD + QE)
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
		g_pCamera->Position += g_pCamera->Front * velocity;
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
		g_pCamera->Position -= g_pCamera->Front * velocity;
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
		g_pCamera->Position -= glm::normalize(glm::cross(g_pCamera->Front, g_pCamera->Up)) * velocity;
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
		g_pCamera->Position += glm::normalize(glm::cross(g_pCamera->Front, g_pCamera->Up)) * velocity;
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
		g_pCamera->Position -= g_pCamera->Up * velocity;
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
		g_pCamera->Position += g_pCamera->Up * velocity;

	// Projection toggles (P/O)
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS) {
		bOrthographicProjection = false;
		g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f); // Reset to perspective view
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS) {
		bOrthographicProjection = true;
		g_pCamera->Position = glm::vec3(0.0f, 10.0f, 0.1f); // Top-down for ortho
		g_pCamera->Front = glm::vec3(0.0f, -1.0f, 0.0f);
	}
}

void ViewManager::PrepareSceneView()
{
	// Timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	ProcessKeyboardEvents();

	// View matrix
	glm::mat4 view = g_pCamera->GetViewMatrix();
	glm::mat4 projection;

	// Projection matrix
	if (bOrthographicProjection) {
		float scale = 0.05f * g_pCamera->Zoom; // Tightened ortho bounds
		projection = glm::ortho(
			-scale * (WINDOW_WIDTH / (float)WINDOW_HEIGHT),
			scale * (WINDOW_WIDTH / (float)WINDOW_HEIGHT),
			-scale, scale,
			0.1f, 100.0f);
	}
	else {
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			(GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
			0.1f, 100.0f);
	}

	if (m_pShaderManager) {
		m_pShaderManager->setMat4Value(g_ViewName, view);
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}